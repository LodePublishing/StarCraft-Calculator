struct Namen
{
	char b[6];
};

const char error_m[9][50]=
{
	"OK",
	"Building availible",
	"enough Minerals",
	"enough Gas",
	"Supply satisfied",
	"Larva availible",
	"Worker availible",
	"researched",
	"Timeout"};

const char error_sm[9]=
{
	        'o','b','m','g','s','l','w','r','t'
};

const Namen kurz[3][60]=
{
	{
	{"Marin"},{"Ghost"},{"Vultu"},{"Golia"},{"STank"},{"SCV  "},{"FiBat"},{"Medic"},{"Wrait"},
	{"SciVe"},{"Drops"},{"BCrui"},{"Valky"},{"CommC"},{"Depot"},{"Refin"},{"Barra"},{"Acade"},
	{"Facto"},{"StarP"},{"SciLa"},{"Engin"},{"Armor"},{"MisTu"},{"Bunke"},{"ComSa"},{"NucSi"},
	{"ConTo"},{"CovOp"},{"PhyLa"},{"MasSh"},{"StimP"},{"LockD"},{"EMPSw"},{"SMine"},{"SiegM"},
	{"Irrad"},{"YamaG"},{"Cloak"},{"PersC"},{"Resto"},{"OptcF"},{"U238S"},{"IonTh"},{"TitaR"},
	{"OculI"},{"MoebR"},{"ApolR"},{"ColoR"},{"CaduR"},{"CharB"},{"InfAr"},{"InfWe"},{"VehAr"},
	{"VehWe"},{"ShpAr"},{"ShpWe"},{"NucWa"},{">>Gas"},{">>Min"}
	},


	{
	{"DarkT"},{"DarkA"},{"Probe"},{"Zealo"},{"Drago"},{"HighT"},{"Archo"},{"Reave"},{"Corsa"},
	{"Shutt"},{"Scout"},{"Arbit"},{"Carri"},{"Obser"},{"Nexus"},{"RobFa"},{"Pylon"},{"Assim"},
	{"ObsTy"},{"GateW"},{"Photo"},{"Cyber"},{"Citad"},{"TempA"},{"Forge"},{"StarG"},{"Fleet"},
	{"ArbTr"},{"RobBy"},{"Shiel"},{"PsiSt"},{"Hallu"},{"Recal"},{"Stasi"},{"Disru"},{"MindC"},
	{"Maels"},{"Singu"},{"LegEn"},{"ScrbD"},{"ReavC"},{"GraDr"},{"Senso"},{"GraBo"},{"KhaAm"},
	{"ApiaS"},{"GraTh"},{"CarCa"},{"KhaCo"},{"ArgJe"},{"ArgTa"},{"Armor"},{"Plati"},{"Groun"},
	{"AirWe"},{"PShie"},{">>Gas"},{">>Min"},{"NULL!"},{"NULL!"}
	},
		
	{
	{"ZLing"},{"Hydra"},{"Ultra"},{"Drone"},{"Defil"},{"Lurkr"},{"Overl"},{"Mutal"},{"Guard"},
	{"Queen"},{"Scour"},{"Devou"},{"Hatch"},{"Lair "},{"Hive "},{"Nydus"},{"HyDen"},{"DeMou"},
	{"GSpir"},{"QNest"},{"EvoCh"},{"UCave"},{"Spire"},{"SPool"},{"Creep"},{"Spore"},{"Sunkn"},
	{"Extra"},{"VSacs"},{"Anten"},{"Pneum"},{"Boost"},{"Adren"},{"Muscu"},{"Groov"},{"Gamet"},
	{"MNode"},{"Chiti"},{"Anabo"},{"Burro"},{"Spawn"},{"Plagu"},{"Consu"},{"Ensna"},{"LAspc"},
	{"Carap"},{"FCarp"},{"Melee"},{"Missl"},{"FAtta"},{">>Gas"},{">>Min"},{"Cancl"},{"NULL!"},
	{"NULL!"},{"NULL!"},{"NULL!"},{"NULL!"},{"NULL!"},{"NULL!"}
	}
};	

