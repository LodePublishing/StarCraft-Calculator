Well, what does this program?

Simply said:
You tell the program (=> in the goal file) what units/buildings/upgrade you
want and the program gives you the (in most cases) fastest build order to
reach your goal.

Setting goals (goal_t.txt, goal_z.txt, goal_p.txt):

- Max Time:
Write here the time in minutes the program should need >at maximum<.
A smaller number may fasten up the beginning at the calculation in some cases. 

- Max Generations:
The more the longer the calculation but the probability is higher that you
really get the fastest way. 9 Max Generations (maximum) means 500
generations, 3 equals 200, 1 equals 100 (50*x+50).

- Max Vespene:
The number of Vespene Geysirs availible near the
hatchery/command center/nexus.

- Mutations:
25 is standard, you could change it to get better results... well... ^^

- Mutation Rate:
50 is standard, same as above (the greater the less mutations)

- The unit list:
A "0" means that the program ignores the entry, though this doesn't have to
mean that the program won't built them.
(example: the program will build high templars if you tell it to build
archons)
If you don't tell the program to build for example a stargate to get scouts
it will also try to get a scout without the stargate :P. Though the program
will still find good solutions the calculation may take longer...
	
Oh, and you must not use any additional numbers in goal_*.txt (that's why I
wrote "twohundredfifty" instead of 250...). It will confuse the program.


Program structure:

The Calculator uses Genetic Algorithms starting with a population of random
generated build orders. The best of these "programs" may copy itself over the
other programs deleting their build order.
Mutations take place changing the build order of a program which (in most
cases) reduce the fitness of it while in a few cases the build order gets
better.
"Fitness" equals points the program get for completing a task/fulfilling a
goal or completing ALL tasks/goals you given in a short time.

Example:
	- your goal: get 5 drones
	- a first approach may be building 5 overlords, then 5 drones
	- due a mutation a program builds only 4 overlords, then 4 drones
              => faster => less time used => more fitness
	... and so on



FAQ:

- Why does the generations-counter jump back again and again?

This is no bug. The program counts down the generations when there is no
change in fitness of the program.

- Why does the program needs several runs to find a good solution?

Well, it happens that the program is stuck in a so called "local minima"
where only a change of the whole build order may result in a better
fitness. Running the program 10 times should guarantee that the best build
order is found.
You may end the program any time pressing a key.

- The program needs soo long to get a result...

Try to reduce the Max Generations. This will really speed up the process
though it may lead to worse results :\
The program needs some cpu speed, so try to let it run "at top" or upgrade
your cpu ;-).

- I don't know how to use the program...

Well, try to experiment with the goals and comparing the results... Or, write
a email to ClawSoftware :)

- How can I help you?

Except sending money and writing emails you may help in these points:
	- You speak an other language than english? Help to translate the
                goal_*.txt/readme.txt or the program text :)
        - You found a spelling error/bug/other error? Tell me about it :)
	- You know the/a formula for gathering minerals/gas? Great :) I am
                really looking for something like that :)
	- You know about genetic programming? Or you know writing good
                looking windows applications? Well, join ClawSoftware :)


Known Bugs:

- The Terra version has a bug in the upgrade section, the program is still
  able to research for example both Charon Boosters and Siege Mode at the same
  time while having only one Machine Shop.
- Terran SCVs and Protoss Probes gather minerals as much as Zerg Drones though
  there is a difference between those races...
- SCVs and Probes need time to get to the building place and time to return
  to the mineral line. As you may (especially with protoss) to build multiple
  buildings with one Probe/SCV there is a little error in the time
  calculation...
- There is no option for the build order to wait until a certain amount of
  minerals are reached (to build for example multiple buildings). This is no
  bug but may improve some build orders when implemented.
- your turn :P Go, find some :)

Future ...

Well, it depends on the feedback I get from you. I have some extra options for
the goal setting (i.e. something like: "Have an air defense after 8 minutes"
or "6 Zerglings after 5 Minutes, but then go straight for mutalisks") and a
more user friendly interface in mind.
And of course, this won't be the last calculator you have seen from
ClawSoftware :) (WarCraft3 will be the next).


	IRC Quakenet: #amb
	scc@clawsoftware.de
Don't hesitate to write your opinion/suggestions/experiences with the program! 
I would also be happy about bug reports or hints to make the program better :)

			Visit www.clawsoftware.de for updates!

This is freeware, you may give it to all your friends if you include all files 
(scecZerg.exe, scsfTerr.exe, sctaProt.exe, readme.txt, goal_t.txt, goal_z.txt,
goal_p.txt and this file readme.txt) though donations are welcome of course...
You may not decompile or change any of the executables without permission.
You may not sell the program or distribute the files without permission.
        Set a direkt link to "http://www.clawsoftware.de" instead.

Copyright by clawsoftware.de.
Warcraft, Starcraft and Starcraft:Broodwar are trademarks of "Blizzard".
